<?php 
	error_reporting(0);
	include 'db.php';
	$kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 1");
	$a = mysqli_fetch_object($kontak);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bukawarung</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<style>
		.col-4 {
			width: 23%;
			margin: 1%;
			float: left;
			box-shadow: 0 2px 8px rgba(0,0,0,0.15);
			border-radius: 10px;
			text-align: center;
			padding: 15px;
			background-color: #fff;
			transition: transform 0.2s;
		}
		.col-4:hover {
			transform: translateY(-5px);
		}
		.col-4 img {
			width: 100%;
			height: 200px;
			object-fit: cover;
			border-radius: 10px;
		}
		.nama {
			font-weight: 600;
			font-size: 16px;
			color: #c0392b;
			margin-top: 10px;
			margin-bottom: 5px;
		}
		.harga {
			color: #27ae60;
			font-size: 15px;
			margin-bottom: 10px;
		}
		.btn-keranjang {
			padding: 7px 16px;
			background-color: #c0392b;
			color: #fff;
			border: none;
			border-radius: 6px;
			cursor: pointer;
			text-decoration: none;
			font-size: 14px;
			transition: background-color 0.3s;
			display: inline-block;
		}
		.btn-keranjang:hover {
			background-color: #e74c3c;
		}

		/* PANEL KERANJANG */
		#panelKeranjang {
			display: none;
			position: fixed;
			top: 0;
			right: 0;
			width: 350px;
			height: 100%;
			background: #fff;
			box-shadow: -2px 0 5px rgba(0,0,0,0.3);
			z-index: 9999;
		}
	</style>
</head>
<body>

	<!-- search -->
	<div class="search">
		<div class="container">
			<form action="produk.php">
				<input type="text" name="search" placeholder="Cari Produk" value="<?php echo $_GET['search'] ?>">
				<input type="hidden" name="kat" value="<?php echo $_GET['kat'] ?>">
				<input type="submit" name="cari" value="Cari Produk">
			</form>
		</div>
	</div>

	<!-- new product -->
	<div class="section">
		<div class="container">
			<h3>Produk</h3>
			<div class="box">
				<?php 
					if($_GET['search'] != '' || $_GET['kat'] != ''){
						$where = "AND product_name LIKE '%".$_GET['search']."%' AND category_id LIKE '%".$_GET['kat']."%' ";
					}

					$produk = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_status = 1 $where ORDER BY product_id DESC");
					if(mysqli_num_rows($produk) > 0){
						while($p = mysqli_fetch_array($produk)){
				?>	
					<a href="detail-produk.php?id=<?php echo $p['product_id'] ?>">
						<div class="col-4">
							<img src="produk/<?php echo $p['product_image'] ?>">
							<div class="nama"><?php echo substr($p['product_name'], 0, 30) ?></div>
							<div class="harga">Rp. <?php echo number_format($p['product_price']) ?></div>
							<a href="tambah-keranjang.php?id=<?php echo $p['product_id'] ?>" class="btn-keranjang" onclick="setTimeout(() => bukaKeranjang(), 300)">+🛒 Keranjang</a>
						</div>
					</a>
				<?php }}else{ ?>
					<p>Produk tidak ada</p>
				<?php } ?>
			</div>
		</div>
	</div>

	<!-- footer -->
	<div class="footer">
		<div class="container">
			<h4>Alamat</h4>
			<p><?php echo $a->admin_address ?></p>

			<h4>Email</h4>
			<p><?php echo $a->admin_email ?></p>

			<h4>No. Hp</h4>
			<p><?php echo $a->admin_telp ?></p>
			<small>Copyright &copy; 2020 - LapakUMKM.</small>
		</div>
	</div>

	<!-- PANEL KERANJANG -->
	<div id="panelKeranjang">
		<div style="padding:10px; background:#c0392b; color:white; font-weight:bold; display:flex; justify-content:space-between;">
			<span>Keranjang</span>
			<button onclick="tutupKeranjang()" style="background:none; border:none; color:white; font-size:16px;">✖</button>
		</div>
		<iframe id="iframeKeranjang" src="keranjang.php" style="width:100%; height:92%; border:none;"></iframe>
	</div>

	<script>
	function bukaKeranjang() {
		document.getElementById("panelKeranjang").style.display = "block";
		document.getElementById("iframeKeranjang").src = "keranjang.php";
	}
	function tutupKeranjang() {
		document.getElementById("panelKeranjang").style.display = "none";
	}
	</script>

</body>
</html>