<?php 
session_start();
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Keranjang</title>
</head>
<body>

<h2>Keranjang Belanja</h2>

<?php 
if(!empty($_SESSION['keranjang'])){
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>No</th><th>Nama Produk</th><th>Harga</th><th>Aksi</th></tr>";
    $no = 1;
    foreach($_SESSION['keranjang'] as $id_produk => $jumlah){
        $query = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_id = $id_produk");
        $data = mysqli_fetch_assoc($query);
        echo "<tr>
            <td>".$no++."</td>
            <td>".$data['product_name']."</td>
            <td>Rp. ".number_format($data['product_price'])."</td>
            <td><a href='hapus-keranjang.php?id=$id_produk'>Hapus</a></td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "<p>Keranjang masih kosong.</p>";
}
?>

</body>
</html>