<?php
session_start();

// Ambil ID produk dari URL
$id_produk = $_GET['id'];

// Kalau belum ada keranjang, buatkan array kosong
if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = array();
}

// Kalau produk sudah ada di keranjang, tambahkan jumlah
if (isset($_SESSION['keranjang'][$id_produk])) {
    $_SESSION['keranjang'][$id_produk] += 1;
} else {
    $_SESSION['keranjang'][$id_produk] = 1;
}

// Arahkan ke halaman keranjang
header("Location: keranjang.php");
exit;
?>