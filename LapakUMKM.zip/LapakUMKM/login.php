<?php
	session_start();
	include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login | Bukawarung</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">

	<style>
		body#bg-login {
			margin: 0;
			padding: 0;
			height: 100vh;
			display: flex;
			justify-content: center;
			align-items: center;
			background: linear-gradient(-45deg, #c70039, #900C3F, #ff4e50, #f9d423);
			background-size: 400% 400%;
			animation: gradientMove 10s ease infinite;
			font-family: 'Quicksand', sans-serif;
		}

		@keyframes gradientMove {
			0% { background-position: 0% 50%; }
			50% { background-position: 100% 50%; }
			100% { background-position: 0% 50%; }
		}

		.box-login {
			background: white;
			padding: 30px 25px;
			border-radius: 12px;
			box-shadow: 0 10px 25px rgba(0,0,0,0.15);
			width: 300px;
			animation: slideIn 1s ease-out;
			text-align: center;
		}

		@keyframes slideIn {
			from {
				transform: translateY(50px);
				opacity: 0;
			}
			to {
				transform: translateY(0);
				opacity: 1;
			}
		}

		.box-login h2 {
			margin-bottom: 20px;
			color: #C70039;
		}

		.input-control {
			width: 100%;
			padding: 10px;
			margin-bottom: 15px;
			border: 1px solid #ddd;
			border-radius: 6px;
		}

		.btn {
			width: 100%;
			padding: 10px;
			background-color: #C70039;
			color: white;
			border: none;
			border-radius: 6px;
			cursor: pointer;
			font-weight: bold;
		}

		.btn:hover {
			background-color: #900C3F;
		}
	</style>
</head>
<body id="bg-login">
	<div class="box-login">
		<h2>🛒 Login ke LapakUMKM</h2>
		<form action="" method="POST">
			<input type="text" name="user" placeholder="Username" class="input-control" required>
			<input type="password" name="pass" placeholder="Password" class="input-control" required>
			<input type="submit" name="submit" value="Login" class="btn">
		</form>
		<?php 
			if(isset($_POST['submit'])){
				session_start();
				include 'db.php';

				$user = mysqli_real_escape_string($conn, $_POST['user']);
				$pass = mysqli_real_escape_string($conn, $_POST['pass']);

				$cek = mysqli_query($conn, "SELECT * FROM tb_admin WHERE username = '".$user."' AND password = '".MD5($pass)."'");
				if(mysqli_num_rows($cek) > 0){
					$d = mysqli_fetch_object($cek);
					$_SESSION['status_login'] = true;
					$_SESSION['a_global'] = $d;
					$_SESSION['id'] = $d->admin_id;
					echo '<script>window.location="dashboard.php"</script>';
				}else{
					echo '<script>alert("Username atau password Anda salah!")</script>';
				}
			}
		?>
	</div>
</body>
</html>