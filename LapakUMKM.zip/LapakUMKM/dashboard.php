<?php 
  session_start();
  if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
  }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>LapakUMKM</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
  <style>
    .marquee-box {
      width: 100%;
      overflow: hidden;
      white-space: nowrap;
      box-sizing: border-box;
    }
    .marquee-text {
      display: inline-block;
      padding-left: 100%;
      animation: scroll-left 10s linear infinite;
      color: #000;
      font-weight: bold;
      font-size: 20px;
    }
    @keyframes scroll-left {
      0% { transform: translateX(0); }
      100% { transform: translateX(-100%); }
    }

    .promo-wrapper {
      overflow: hidden;
      width: 100%;
    }
    .promo-track {
      display: flex;
      animation: slide 30s linear infinite;
    }
    .promo-track img {
      width: 300px;
      margin-right: 10px;
      border-radius: 10px;
    }
    @keyframes slide {
      0% { transform: translateX(0); }
      100% { transform: translateX(-4200px); } /* total 14 gambar (7x2) = 300px*7*2 */
    }
  </style>
</head>
<body>

  <!-- header -->
  <header>
    <div class="container">
      <h1><a href="dashboard.php">LapakUMKM</a></h1>
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="profil.php">Profil</a></li>
        <li><a href="data-kategori.php">Data Kategori</a></li>
        <li><a href="data-produk.php">Data Produk</a></li>
        <li><a href="keluar.php">Keluar</a></li>
      </ul>
    </div>
  </header>

  <!-- content -->
  <div class="section">
    <div class="container">
      <h3>Dashboard</h3>
      <div class="box">
        <div class="marquee-box">
          <div class="marquee-text">👋 Selamat Datang <?php echo $_SESSION['a_global']->admin_name ?> di Toko Online LapakUMKM 🎉</div>
        </div>
      </div>

      <!-- Promo Auto Geser -->
      <div class="box" style="margin-top:20px;">
        <div class="promo-wrapper">
          <div class="promo-track">
            <!-- Gambar promo di duplikat 2x supaya looping smooth -->
            <img src="promo/promo1.jpg">
            <img src="promo/promo2.jpg">
            <img src="promo/promo3.jpg">
            <img src="promo/promo4.jpg">
            <img src="promo/promo5.jpg">
            <img src="promo/promo6.jpg">
            <img src="promo/promo7.jpg">

            <img src="promo/promo1.jpg">
            <img src="promo/promo2.jpg">
            <img src="promo/promo3.jpg">
            <img src="promo/promo4.jpg">
            <img src="promo/promo5.jpg">
            <img src="promo/promo6.jpg">
            <img src="promo/promo7.jpg">
          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- footer -->
  <footer>
    <div class="container">
      <small>Copyright &copy; 2020 - LapakUMKM.</small>
    </div>
  </footer>

</body>
</html>