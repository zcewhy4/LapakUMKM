<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo "Silakan login dulu.";
    exit;
}

$id_user = $_SESSION['user_id'];
$keranjang = $_SESSION['keranjang'] ?? [];

$total = 0;
foreach ($keranjang as $id => $jumlah) {
    $data = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
    $produk = mysqli_fetch_assoc($data);
    $total += $produk['harga'] * $jumlah;
}

mysqli_query($conn, "INSERT INTO transaksi (id_user, total) VALUES ($id_user, $total)");
$id_transaksi = mysqli_insert_id($conn);

foreach ($keranjang as $id => $jumlah) {
    $data = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
    $produk = mysqli_fetch_assoc($data);
    mysqli_query($conn, "INSERT INTO detail_transaksi (id_transaksi, id_produk, jumlah, harga) 
    VALUES ($id_transaksi, $id, $jumlah, {$produk['harga']})");
}

unset($_SESSION['keranjang']);
echo "Pembelian berhasil! <a href='produk.php'>Kembali belanja</a>";
?>