-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2025 at 06:00 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_lapakumkm`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id` int(11) NOT NULL,
  `id_transaksi` int(11) DEFAULT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_telp` varchar(20) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(1, 'wahyu arifin hidayat', 'admin123', '0192023a7bbd73250516f069df18b500', '+6287714362767', 'wahyuarifinhidayat2105@gmail.com', 'Jl. Petojo VIJ VI, Cideng, Gambir, Jakarta Pusat 10150.');

-- --------------------------------------------------------

--
-- Table structure for table `tb_category`
--

CREATE TABLE `tb_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_category`
--

INSERT INTO `tb_category` (`category_id`, `category_name`) VALUES
(5, 'Handphone'),
(6, 'Handsfree'),
(7, 'Pakaian Pria'),
(8, 'Pakaian Wanita'),
(9, 'Buah'),
(10, 'Sayur'),
(11, 'PC'),
(12, 'macbook'),
(13, 'car'),
(14, 'IPhone'),
(15, 'sembako'),
(16, 'Martabak'),
(17, 'Indomie');

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_description` text NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_status` tinyint(1) NOT NULL,
  `data_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`product_id`, `category_id`, `product_name`, `product_price`, `product_description`, `product_image`, `product_status`, `data_created`) VALUES
(5, 4, 'Laptop TUF Gaming F15, 15.6\", Nvidia GeForce RTX 3050, Intel Core i5-12500H, RAM 16 GB, SSD 512 GB, ', 16499000, '<p><strong>Layar: 15.6&quot; Full HD IPS, refresh rate 144Hz (nyaman untuk gaming kompetitif)</strong></p>\r\n\r\n<p><strong>Prosesor: Intel Core i5-12500H (12th Gen, 12 core, powerful untuk gaming &amp; multitasking)</strong></p>\r\n\r\n<p><strong>VGA / GPU: NVIDIA GeForce RTX 3050 (4GB GDDR6, support ray tracing &amp; DLSS)</strong></p>\r\n\r\n<p><strong>RAM: 16 GB DDR4 (bisa upgrade hingga 32GB)</strong></p>\r\n\r\n<p><strong>Penyimpanan: SSD 512 GB NVMe (super cepat buat loading game &amp; aplikasi)</strong></p>\r\n\r\n<p><strong>Warna: Gris (abu-abu elegan, desain khas TUF Gaming)</strong></p>\r\n\r\n<p><br />\r\n<strong>Fitur Tambahan:</strong></p>\r\n\r\n<p><strong>Sistem pendingin canggih anti panas saat main lama</strong></p>\r\n\r\n<p><strong>Build quality military-grade (tahan banting, kokoh)</strong></p>\r\n\r\n<p><strong>RGB Backlit Keyboard (tampilan gaming banget)</strong></p>\r\n\r\n<p><strong>Windows 11 Original</strong></p>\r\n\r\n<p><br />\r\n<strong>Deskripsi Singkat:<br />\r\nLaptop TUF Gaming F15 cocok buat para gamers, content creator, maupun mahasiswa yang butuh performa tinggi. Desain gagah, performa cepat, dan sudah didukung kartu grafis RTX 3050 untuk bermain game AAA&nbsp;maupun editing berat.</strong></p>\r\n', 'produk1749696482.png', 1, '2020-05-19 01:52:15'),
(6, 13, 'Nissan GT-R Premium 2018 ', 2147483647, '<p>Nissan GT-R Premium 2018 merupakan salah satu mobil sport legendaris yang menawarkan performa luar biasa dengan teknologi canggih. Ditenagai oleh mesin V6 Twin-Turbocharged 3.8L, mobil ini mampu menghasilkan tenaga hingga 565 HP. Dengan desain aerodinamis yang agresif, interior mewah berbalut kulit premium, serta sistem penggerak AWD (All-Wheel Drive), GT-R memberikan pengalaman berkendara yang stabil dan bertenaga. Sangat cocok untuk pecinta kecepatan yang menginginkan kenyamanan dan performa dalam satu paket.</p>\r\n\r\n<p>Spesifikasi Utama:</p>\r\n\r\n<p>Tahun: 2018</p>\r\n\r\n<p>Mesin: 3.8L Twin-Turbocharged V6</p>\r\n\r\n<p>Tenaga: 565 HP @ 6,800 RPM</p>\r\n\r\n<p>Torsi: 633 Nm</p>\r\n\r\n<p>Transmisi: 6-speed Dual-Clutch Automatic</p>\r\n\r\n<p>Sistem Penggerak: All-Wheel Drive (AWD)</p>\r\n\r\n<p>0-100 km/jam: &plusmn; 3.0 detik</p>\r\n\r\n<p>Kecepatan Maksimum: &plusmn; 315 km/jam</p>\r\n\r\n<p>Warna: Silver/Grey (opsional warna sesuai stock)</p>\r\n\r\n<p>Interior: Kulit Premium + Fitur Hiburan Bose Audio</p>\r\n\r\n<p>Fitur Tambahan: Launch Control, Adaptive Suspension, Advanced Navigation System</p>\r\n', 'produk1749698349.png', 1, '2020-05-19 01:52:45'),
(7, 15, 'sembako paket', 150000, '<p>Paket Sembako Hemat ini cocok untuk kebutuhan rumah tangga harian, bantuan sosial, maupun stok bulanan. Berisi berbagai kebutuhan pokok dengan kualitas terbaik dan kemasan praktis, hemat waktu dan biaya.</p>\r\n\r\n<p>Isi paket sudah disesuaikan untuk kebutuhan keluarga selama 1-2 minggu. Semua produk segar, berkualitas, dan aman dikonsumsi.</p>\r\n\r\n<p>Isi Paket:</p>\r\n\r\n<p>Beras Premium 5 kg</p>\r\n\r\n<p>Minyak Goreng 2 Liter</p>\r\n\r\n<p>Gula Pasir 1 kg</p>\r\n\r\n<p>Tepung Terigu 1 kg</p>\r\n\r\n<p>Garam Halus 500 gr</p>\r\n\r\n<p>Susu Kental Manis 2 Kaleng</p>\r\n\r\n<p>Mie Instan 10 Bungkus</p>\r\n\r\n<p>Kopi Sachet 1 Pack (10 sachet)</p>\r\n\r\n<p>Teh Celup 1 Pack</p>\r\n\r\n<p>Sabun Mandi 2 batang</p>\r\n\r\n<p>Pasta Gigi 1 tube</p>\r\n\r\n<p>Spesifikasi Tambahan</p>\r\n\r\n<p>Kategori: Sembako &amp; Kebutuhan Harian</p>\r\n\r\n<p>Kondisi: Baru</p>\r\n\r\n<p>Berat Paket: &plusmn;10 kg</p>\r\n\r\n<p>Pengemasan: Kardus Rapi &amp; Safety Packaging</p>\r\n\r\n<p>Pengiriman: Instant / Same Day / Reguler</p>\r\n\r\n<p>Cocok Untuk:</p>\r\n\r\n<p>Kebutuhan harian rumah tangga</p>\r\n\r\n<p>Bantuan sosial</p>\r\n\r\n<p>Kegiatan bakti sosial</p>\r\n\r\n<p>Parcel lebaran, natal, &amp; tahun baru</p>\r\n\r\n<p>Persediaan bulanan kantor</p>\r\n', 'produk1749699189.png', 1, '2020-05-19 01:53:02'),
(8, 16, 'paket buah-buahan', 125000, '<p>Paket buah-buahan segar yang dikemas cantik dalam keranjang, cocok untuk hadiah, parcel lebaran, ulang tahun, maupun konsumsi pribadi. Semua buah dipilih dengan kualitas premium, segar dari petani lokal.</p>\r\n\r\n<p>Isi Paket:</p>\r\n\r\n<p>Apel Fuji (4 buah)</p>\r\n\r\n<p>Jeruk Sunkist (4 buah)</p>\r\n\r\n<p>Pir (2 buah)</p>\r\n\r\n<p>Anggur Merah Seedless (500 gram)</p>\r\n\r\n<p>Buah Naga (1 buah)</p>\r\n\r\n<p>Pisang Ambon (1 sisir kecil)</p>\r\n\r\n<p>Melon (1 buah)</p>\r\n\r\n<p>Hiasan daun sintetis</p>\r\n\r\n<p>Keranjang anyaman rotan + plastik wrapping + pita hias</p>\r\n\r\n<p>Spesifikasi Tambahan</p>\r\n\r\n<p>Kategori: Buah Segar &amp; Parcel</p>\r\n\r\n<p>Kondisi: Baru</p>\r\n\r\n<p>Berat Paket: &plusmn;5 kg</p>\r\n\r\n<p>Kemasan: Keranjang anyaman, wrapping rapi</p>\r\n\r\n<p>Pengiriman: Instant / Same Day / Reguler</p>\r\n\r\n<p>Keterangan: Stock buah dapat menyesuaikan ketersediaan</p>\r\n\r\n<p>Cocok Untuk:</p>\r\n\r\n<p>Parcel hadiah</p>\r\n\r\n<p>Bingkisan perusahaan</p>\r\n\r\n<p>Ulang tahun</p>\r\n\r\n<p>Hari besar (Lebaran, Natal, Imlek)</p>\r\n\r\n<p>Konsumsi pribadi / keluarga</p>\r\n', 'produk1749699435.png', 1, '2020-05-19 01:53:23'),
(9, 14, 'Apple IPhone 15 Pro Max ', 23999000, '<p>iPhone 15 Pro Max hadir dengan bodi Titanium kelas aerospace, membuatnya lebih ringan, kokoh, dan premium dari generasi sebelumnya. Ditenagai oleh chip A17 Pro 3nm terbaru, memberikan performa gaming kelas konsol, efisiensi baterai luar biasa, dan pengalaman multitasking super cepat.</p>\r\n\r\n<p>Sistem kamera Pro baru menghadirkan teknologi zoom optik hingga 5x, kamera utama 48 MP dengan kualitas foto raw profesional, serta kemampuan pengambilan video sinematik hingga 4K 60fps ProRes. Desain dynamic island tetap hadir untuk tampilan interaktif di bagian atas layar.</p>\r\n\r\n<p>Port USB-C menggantikan lightning, memungkinkan transfer data super cepat, pengisian daya efisien, serta kompatibilitas lebih luas dengan aksesoris modern.</p>\r\n\r\n<p><br />\r\n---</p>\r\n\r\n<p>🔧 Spesifikasi Teknis</p>\r\n\r\n<p>Chipset: Apple A17 Pro (3nm) &mdash; CPU 6-core &amp; GPU 6-core, Pro-class Gaming</p>\r\n\r\n<p>RAM: 8 GB</p>\r\n\r\n<p>Internal Storage:</p>\r\n\r\n<p>256 GB</p>\r\n\r\n<p>512 GB</p>\r\n\r\n<p>1 TB</p>\r\n\r\n<p><br />\r\nLayar:</p>\r\n\r\n<p>6.7 inci LTPO Super Retina XDR OLED</p>\r\n\r\n<p>Resolusi: 1290 x 2796 piksel</p>\r\n\r\n<p>120Hz ProMotion</p>\r\n\r\n<p>HDR10 &amp; Dolby Vision</p>\r\n\r\n<p><br />\r\nKamera Belakang:</p>\r\n\r\n<p>48 MP (Wide) f/1.78, sensor shift OIS</p>\r\n\r\n<p>12 MP (Ultra-Wide) f/2.2, 120&deg; FOV</p>\r\n\r\n<p>12 MP (Telephoto Periscope 5x optical zoom) f/2.8</p>\r\n\r\n<p><br />\r\nKamera Depan: 12 MP (TrueDepth, f/1.9)</p>\r\n\r\n<p>Video Recording:</p>\r\n\r\n<p>4K hingga 60 fps</p>\r\n\r\n<p>ProRes, Cinematic Mode, Action Mode</p>\r\n\r\n<p><br />\r\nBaterai: &plusmn;4422 mAh</p>\r\n\r\n<p>Fast charging 25W</p>\r\n\r\n<p>MagSafe Wireless Charging 15W</p>\r\n\r\n<p><br />\r\nMaterial Body: Titanium Grade 5 (Aerospace-grade)</p>\r\n\r\n<p>Konektivitas:</p>\r\n\r\n<p>5G</p>\r\n\r\n<p>Wi-Fi 6E</p>\r\n\r\n<p>Bluetooth 5.3</p>\r\n\r\n<p>USB-C 3.0</p>\r\n\r\n<p>NFC</p>\r\n\r\n<p><br />\r\nSistem Operasi: iOS 17 (Upgradable)</p>\r\n\r\n<p>Fitur Tambahan:</p>\r\n\r\n<p>Face ID</p>\r\n\r\n<p>Emergency SOS via Satellite</p>\r\n\r\n<p>Crash Detection</p>\r\n\r\n<p>Always-On Display</p>\r\n\r\n<p>Dynamic Island</p>\r\n\r\n<p><br />\r\n---</p>\r\n\r\n<p>🎨 Pilihan Warna</p>\r\n\r\n<p>Natural Titanium</p>\r\n\r\n<p>Blue Titanium</p>\r\n\r\n<p>White Titanium</p>\r\n\r\n<p>Black Titanium</p>\r\n', 'produk1749698901.png', 1, '2020-05-19 01:53:46'),
(10, 5, 'Samsung Galaxy A55 5G', 5999000, '<p><strong>Samsung Galaxy A55 5G hadir dengan desain premium dan performa yang kencang di kelas menengah. Ditenagai oleh prosesor Exynos 1480, didukung RAM besar dan layar Super AMOLED yang sangat tajam, memberikan pengalaman multimedia dan gaming yang memuaskan. Kamera berkualitas tinggi dengan fitur OIS mampu menghasilkan foto dan video yang stabil dan jernih, bahkan di kondisi minim cahaya.</strong></p>\r\n\r\n<p><strong>Spesifikasi Utama:</strong></p>\r\n\r\n<p><strong>Layar: 6.6 inci Super AMOLED, 120Hz, Full HD+</strong></p>\r\n\r\n<p><strong>Prosesor: Exynos 1480 (4nm)</strong></p>\r\n\r\n<p><strong>RAM: 8 GB</strong></p>\r\n\r\n<p><strong>Memori Internal: 256 GB (dapat diperluas dengan microSD)</strong></p>\r\n\r\n<p><strong>Kamera Belakang: Triple Camera 50 MP (OIS) + 12 MP Ultra Wide + 5 MP Macro</strong></p>\r\n\r\n<p><strong>Kamera Depan: 32 MP</strong></p>\r\n\r\n<p><strong>Baterai: 5000 mAh, Fast Charging 25W</strong></p>\r\n\r\n<p><strong>Sistem Operasi: Android 14 dengan One UI 6.1</strong></p>\r\n\r\n<p><strong>Keamanan: Fingerprint di layar, Samsung Knox</strong></p>\r\n\r\n<p><strong>Konektivitas: 5G, WiFi 6, Bluetooth 5.3, NFC</strong></p>\r\n\r\n<p><strong>Warna: Awesome Iceblue, Awesome Navy, Awesome Lilac, Awesome Lemon</strong></p>\r\n', 'produk1749698620.png', 1, '2020-05-19 01:54:16'),
(11, 6, 'Handsfree DIZA100 Casque Gaming PS4, Casque Gaming Xbox One RGB LED Lampe Casque Gamer Audio Stéréo ', 599000, '<p>Headset gaming DIZA100 dirancang untuk memberikan pengalaman audio imersif saat bermain game di berbagai platform seperti PS4, Xbox One, PC, dan laptop. Dengan fitur RGB LED yang keren, suara stereo berkualitas tinggi, serta efek bass yang dalam, headset ini membuat suara dalam game menjadi lebih nyata. Dilengkapi dengan mikrofon fleksibel dan noise-cancelling, komunikasi tim jadi lebih jernih tanpa gangguan. Desainnya ergonomis, nyaman dipakai dalam sesi bermain game yang lama.</p>\r\n\r\n<p>Spesifikasi Utama:</p>\r\n\r\n<p>Kompatibel: PS4, Xbox One, PC, Laptop</p>\r\n\r\n<p>Tipe suara: Audio Stereo dengan efek bass</p>\r\n\r\n<p>Fitur lampu: RGB LED lighting</p>\r\n\r\n<p>Mikrofon: Noise Cancelling &amp; adjustable</p>\r\n\r\n<p>Konektor: 3.5mm jack + USB (untuk lampu LED)</p>\r\n\r\n<p>Warna: Hitam</p>\r\n\r\n<p>Bahan: Headband empuk, earmuff nyaman</p>\r\n\r\n<p>Berat: &plusmn; 400 gram</p>\r\n', 'produk1749698016.png', 1, '2020-05-19 01:54:46'),
(12, 12, 'MacBook Pro 16-inch Space Gray', 42599999, '<p><strong>MacBook Pro 16-inch hadir dengan desain elegan Space Gray, cocok untuk profesional yang membutuhkan performa tinggi dan tampilan premium. Ditenagai oleh prosesor Apple M1 Pro/Max, laptop ini menawarkan kecepatan luar biasa untuk multitasking, editing video, dan pekerjaan berat lainnya. Dilengkapi layar Retina 16 inci dengan resolusi tinggi, warna yang tajam, dan tingkat kecerahan tinggi, memberikan pengalaman visual terbaik. Sistem pendinginan canggih, keyboard nyaman, serta baterai tahan lama membuatnya ideal untuk pekerjaan sehari-hari maupun mobilitas tinggi.</strong></p>\r\n\r\n<p><strong>Spesifikasi Utama:</strong></p>\r\n\r\n<p><strong>Prosesor: Apple M1 Pro / Max</strong></p>\r\n\r\n<p><strong>Layar: Retina 16-inch (3456 x 2234 piksel)</strong></p>\r\n\r\n<p><strong>RAM: 16GB / 32GB</strong></p>\r\n\r\n<p><strong>Penyimpanan: 512GB / 1TB SSD</strong></p>\r\n\r\n<p><strong>Warna: Space Gray</strong></p>\r\n\r\n<p><strong>Sistem Operasi: macOS terbaru</strong></p>\r\n\r\n<p><strong>Port: Thunderbolt 4, HDMI, SDXC card slot, MagSafe 3</strong></p>\r\n\r\n<p><strong>Berat: &plusmn; 2.1 kg</strong></p>\r\n', 'produk1749697489.png', 1, '2020-05-19 01:55:15'),
(13, 11, 'PC Gamer Completo Ryzen 5 5600G, 16GB DDR4, SSD 480GB, 500W 80 Plus, PCGC17-E', 9999000, '<p><strong>Prosesor (CPU): AMD Ryzen 5 5600G (6-Core / 12-Thread, clock up to 4.4GHz, performa tinggi &amp; hemat daya)</strong></p>\r\n\r\n<p><strong>RAM: 16GB DDR4 (dual channel, multitasking lancar)</strong></p>\r\n\r\n<p><strong>Penyimpanan: SSD 480GB (super cepat loading game &amp; aplikasi)</strong></p>\r\n\r\n<p><strong>Power Supply: 500W 80 Plus (efisien dan stabil)</strong></p>\r\n\r\n<p><strong>VGA / GPU: Integrated Radeon Vega 7 (bisa main game AAA dengan setting medium)</strong></p>\r\n\r\n<p><strong>Casing: Desain gaming RGB transparan elegan (seperti di gambar)</strong></p>\r\n\r\n<p><strong>Pendingin: Airflow optimal dengan fan RGB tambahan</strong></p>\r\n\r\n<p><strong>Kelengkapan Tambahan:</strong></p>\r\n\r\n<p><strong>Monitor gaming curved</strong></p>\r\n\r\n<p><strong>Keyboard mechanical RGB</strong></p>\r\n\r\n<p><strong>Gaming mouse RGB</strong></p>\r\n\r\n<p><strong>Headset gaming</strong></p>\r\n\r\n<p><strong>Fitur Unggulan:</strong></p>\r\n\r\n<p><strong>Cocok untuk game Esports seperti Valorant, CS:GO, Dota 2, Mobile Legends, Fortnite, Genshin Impact, dll.</strong></p>\r\n\r\n<p><strong>Kuat untuk editing video ringan - sedang.</strong></p>\r\n\r\n<p><strong>Suara kipas halus &amp; pendinginan maksimal.</strong></p>\r\n\r\n<p><strong>Bisa upgrade VGA eksternal (support GPU dedicated di kemudian hari).</strong></p>\r\n\r\n<p><br />\r\n<strong>Deskripsi Singkat:<br />\r\nPC Gaming Completo Ryzen 5 5600G adalah solusi ekonomis untuk para gamer, content creator, maupun pekerja kantoran yang ingin performa tinggi dengan harga terjangkau. Dengan desain elegan dan aksesoris lengkap, kamu langsung bisa main tanpa ribet rakit lagi.</strong></p>\r\n', 'produk1749696947.png', 1, '2020-05-19 01:55:42'),
(14, 7, 'kaos  T-shirt', 150000, '<p><strong>Kaos putih simpel dengan gaya skena kekinian, cocok untuk anak muda yang ingin tampil santai namun tetap stylish. Terbuat dari bahan katun premium yang lembut, adem, dan nyaman dipakai sepanjang hari. Desain minimalis cocok dipadukan dengan berbagai outfit, baik celana jeans, chino, maupun short pants.</strong></p>\r\n', 'produk1749696154.png', 1, '2020-05-19 01:56:10'),
(15, 7, 'pakaian pria busana', 150000, '<p><strong>Busana pria warna hitam elegan, cocok untuk segala aktivitas formal maupun kasual. Dengan bahan berkualitas, adem, dan nyaman dipakai sepanjang hari. Warna hitam yang netral memberikan kesan maskulin, modern, dan mudah dipadukan dengan berbagai gaya.</strong></p>\r\n', 'produk1589853389.png', 1, '2020-05-19 01:56:29'),
(16, 8, 'pakaian wanita busana', 200000, '<p><strong>Busana wanita elegan warna biru yang memancarkan kesan segar dan anggun. Cocok digunakan untuk kegiatan sehari-hari maupun acara spesial. Didesain dengan bahan yang nyaman, adem, dan ringan saat dipakai, membuat penampilan makin menawan.</strong></p>\r\n\r\n<p><br />\r\n<strong>Busana wanita warna coklat dengan nuansa hangat yang menawan. Sangat cocok untuk gadis muda yang ingin tampil kalem namun tetap stylish. Bahan berkualitas, nyaman digunakan, serta desain simpel yang mudah dipadukan dengan aksesoris favorit.</strong></p>\r\n', 'produk1589853410.png', 1, '2020-05-19 01:56:50'),
(17, 8, 'pakaian wanita cream', 400000, '<p><strong>Tampil anggun dan manis dengan pakaian wanita warna cream yang elegan. Desain simpel namun memikat, sangat cocok dikenakan oleh gadis muda untuk acara santai maupun semi-formal. Bahan adem, nyaman dipakai seharian, dan mudah dipadukan dengan berbagai aksesoris. Pilihan sempurna untuk tampil percaya diri.</strong></p>\r\n', 'produk1749695432.png', 1, '2020-05-19 01:57:11'),
(18, 9, 'pisang', 15000, '<p><strong>Pisang segar berkualitas premium, manis alami, dan tekstur lembut. Cocok untuk camilan sehat, campuran smoothie, atau bahan olahan kue. Mengandung vitamin B6, kalium, serta serat tinggi yang baik untuk pencernaan dan kesehatan jantung.</strong></p>\r\n', 'produk1589853455.png', 1, '2020-05-19 01:57:35'),
(19, 9, 'rambutan', 20000, '<p><strong>Rambutan segar dengan rasa manis, daging buah tebal, dan biji kecil. Dipetik langsung dari kebun pilihan untuk menjaga kualitas dan kesegarannya. Sangat cocok dinikmati sebagai camilan sehat, campuran rujak, atau tambahan dalam minuman dingin. Mengandung vitamin C, serat, dan antioksidan yang baik untuk menjaga daya tahan tubuh.</strong></p>\r\n', 'produk1589853479.png', 1, '2020-05-19 01:57:59'),
(20, 10, 'brokoli', 30000, '<p><strong>Brokoli segar hijau cerah, kaya akan nutrisi, vitamin C, serat, dan antioksidan. Cocok diolah untuk sup, tumis, salad, maupun direbus sebagai menu diet sehat. Dipanen dari kebun berkualitas, dijamin segar dan higienis. Berat per ikat sekitar 250-500 gram. Dikemas rapi untuk menjaga kesegaran saat diterima pembeli.</strong></p>\r\n', 'produk1589853498.png', 1, '2020-05-19 01:58:18'),
(21, 10, 'sayur kol ', 40000, '<p><strong>Kol segar berkualitas dengan daun renyah, tebal, dan bersih. Sangat cocok digunakan untuk masakan seperti tumis, sop, lalapan, ataupun isian bakso dan siomay. Mengandung serat tinggi, vitamin C, dan antioksidan yang baik untuk kesehatan tubuh. Berat per buah sekitar 800 gram hingga 1,5 kg, dikemas rapi agar tetap segar saat sampai di tangan pembeli.</strong></p>\r\n', 'produk1589853518.png', 1, '2020-05-19 01:58:38'),
(22, 17, 'indomie goreng aceh', 4000, '<p>indomie goreng aceh limit edision</p>\r\n', 'produk1749801437.png', 1, '2025-06-13 07:57:17');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_category`
--
ALTER TABLE `tb_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
