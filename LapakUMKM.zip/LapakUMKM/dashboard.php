<?php 
	session_start();
	if($_SESSION['status_login'] != true){
		echo '<script>window.location="login.php"</script>';
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Bukawarung</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<style>
		.marquee-box {
			width: 100%;
			overflow: hidden;
			white-space: nowrap;
			box-sizing: border-box;
		}
		.marquee-text {
			display: inline-block;
			padding-left: 100%;
			animation: scroll-left 10s linear infinite;
			color: #000;
			font-weight: bold;
			font-size: 20px;
		}
		@keyframes scroll-left {
			0% { transform: translateX(0); }
			100% { transform: translateX(-100%); }
		}
	</style>
</head>
<body>

	<!-- header -->
	<header>
		<div class="container">
			<h1><a href="dashboard.php">LapakUMKM</a></h1>
			<ul>
				<li><a href="dashboard.php">Dashboard</a></li>
				<li><a href="profil.php">Profil</a></li>
				<li><a href="produk.php">Produk</a></li>
				<li><a href="data-kategori.php">Data Kategori</a></li>
				<li><a href="data-produk.php">Data Produk</a></li>
				<li><a href="keluar.php">Keluar</a></li>
			</ul>
		</div>
	</header>

	<!-- content -->
	<div class="section">
		<div class="container">
			<h3>Dashboard</h3>
			<div class="box">
				<div class="marquee-box">
					<div class="marquee-text">👋 Selamat Datang <?php echo $_SESSION['a_global']->admin_name ?> di Toko Online LapakUMKM 🎉</div>
				</div>
			</div>

			<!-- PROMO BERGAMBAR -->
			<div class="box" style="overflow-x: auto; white-space: nowrap; margin-bottom: 20px;">
				<img src="promo/promo1.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
				<img src="promo/promo2.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
				<img src="promo/promo3.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
				<img src="promo/promo4.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
				<img src="promo/promo5.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
				<img src="promo/promo6.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
				<img src="promo/promo7.jpg" style="width:300px; margin-right:10px; border-radius:10px;">
			</div>

		</div>
	</div>

	<!-- footer -->
	<footer>
		<div class="container">
			<small>Copyright &copy; 2020 - LapakUMKM.</small>
		</div>
	</footer>

</body>
</html>