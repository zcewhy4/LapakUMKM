<?php
	session_start();
	include 'db.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login LapakUMKM</title>
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

	<style>
		* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Quicksand', sans-serif; }
		body {
			height: 100vh;
			background: url('login/login.jpg') no-repeat center center/cover;
			display: flex;
			justify-content: center;
			align-items: center;
		}
		.login-container {
			background: rgba(255, 255, 255, 0.1);
			padding: 40px 30px;
			border-radius: 15px;
			backdrop-filter: blur(15px);
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
			width: 350px;
			color: #fff;
		}
		.login-container h2 { text-align: center; margin-bottom: 30px; color: #fff; }
		.input-group { position: relative; margin-bottom: 25px; }
		.input-group input {
			width: 100%; padding: 10px 10px 10px 40px;
			background: transparent; border: 2px solid #fff;
			border-radius: 8px; color: #fff;
			outline: none; font-size: 16px;
		}
		.input-group label {
			position: absolute; top: 50%; left: 45px;
			color: #ccc; transform: translateY(-50%);
			transition: .3s; pointer-events: none;
		}
		.input-group input:focus ~ label,
		.input-group input:not(:placeholder-shown) ~ label {
			top: -10px; left: 40px; font-size: 12px;
			color: #ff4e50; background: rgba(0,0,0,0.3);
			padding: 0 5px; border-radius: 5px;
		}
		.input-group .icon {
			position: absolute; top: 50%; left: 10px;
			transform: translateY(-50%); color: #fff;
		}
		.btn {
			width: 100%; padding: 12px; background: #ff4e50;
			border: none; color: #fff; font-weight: bold;
			border-radius: 8px; cursor: pointer;
			transition: 0.3s; margin-bottom: 15px;
		}
		.btn:hover { background: #c70039; }
		.options {
			display: flex; justify-content: space-between;
			align-items: center; margin-bottom: 20px; font-size: 13px;
		}
		.register-text {
			text-align: center; font-size: 14px;
		}
		.register-text a {
			color: #ff4e50; text-decoration: none; font-weight: bold;
		}
	</style>

	<script>
		function startLogin() {
			// disable tombol
			document.getElementById("submitBtn").disabled = true;
			document.getElementById("submitBtn").value = "Tunggu...";

			// play audio
			var audio = new Audio('login/suara-login.mp3');
			audio.play();

			// saat audio selesai
			audio.onended = function() {
				document.getElementById("submitBtn").value = "Sedang Login...";
				document.getElementById("loginForm").submit();
			}
		}
	</script>
</head>
<body>
	<div class="login-container">
		<h2>Login LapakUMKM</h2>
		<form id="loginForm" action="" method="POST">
			<div class="input-group">
				<i class="fas fa-user icon"></i>
				<input type="text" name="user" placeholder=" " class="input-control" required>
				<label>Username</label>
			</div>
			<div class="input-group">
				<i class="fas fa-lock icon"></i>
				<input type="password" name="pass" placeholder=" " class="input-control" required>
				<label>Password</label>
			</div>

			<div class="options">
				<div>
					<input type="checkbox" id="remember">
					<label for="remember">Remember Me</label>
				</div>
				<div>
					<a href="#">Forgot Password?</a>
				</div>
			</div>

			<input type="button" id="submitBtn" value="Login" class="btn" onclick="startLogin()">
		</form>

		<div class="register-text">
			Don't have an account? <a href="register-user.php">Register</a>
		</div>

		<?php 
			if($_SERVER["REQUEST_METHOD"] == "POST"){
				$user = mysqli_real_escape_string($conn, $_POST['user']);
				$pass = mysqli_real_escape_string($conn, $_POST['pass']);

				$cek = mysqli_query($conn, "SELECT * FROM tb_admin WHERE username = '".$user."' AND password = '".MD5($pass)."'");
				if(mysqli_num_rows($cek) > 0){
					$d = mysqli_fetch_object($cek);
					$_SESSION['status_login'] = true;
					$_SESSION['a_global'] = $d;
					$_SESSION['id'] = $d->admin_id;
					echo '<script>window.location="dashboard.php"</script>';
				}else{
					echo '<script>alert("Username atau password Anda salah!")</script>';
				}
			}
		?>
	</div>
</body>
</html>