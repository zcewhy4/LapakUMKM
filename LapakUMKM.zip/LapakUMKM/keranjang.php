<?php 
session_start();
include 'db.php';

// Cek apakah admin sudah login
if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Keranjang Belanja</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        header {
            background: #C70039;
            padding: 15px 0;
        }
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        header ul {
            list-style: none;
            display: flex;
            gap: 15px;
            margin: 0;
        }
        header ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        .btn-kembali {
            background-color: #C70039;
            color: white;
            border: none;
            padding: 10px 25px;
            font-weight: bold;
            border-radius: 6px;
            text-decoration: none;
        }
        .btn-kembali:hover {
            background-color: #a6002e;
            color: white;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .container-content {
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="container-content">

    <!-- TAMPIL ADMIN DI ATAS -->
    <div style="margin-bottom:20px; padding:10px; background:#fff; border:1px solid #ddd; border-radius:8px;">
        <strong>Admin Login:</strong> <span style="color:#C70039;"><?php echo $_SESSION['a_global']->admin_name ?></span>
    </div>

    <h2 class="mb-4">🛒 Keranjang Belanja</h2>

    <?php if (!empty($_SESSION['keranjang'])): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped text-center">
                <thead class="table-danger">
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    $total = 0;
                    foreach ($_SESSION['keranjang'] as $id_produk => $jumlah):
                        $query = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_id = '$id_produk'");
                        $produk = mysqli_fetch_assoc($query);

                        if ($produk): 
                            $subtotal = $produk['product_price'] * $jumlah;
                            $total += $subtotal;
                    ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($produk['product_name']) ?></td>
                            <td>Rp <?= number_format($produk['product_price']) ?></td>
                            <td><?= $jumlah ?></td>
                            <td>Rp <?= number_format($subtotal) ?></td>
                            <td><a href="hapus-keranjang.php?id=<?= $id_produk ?>" class="btn btn-sm btn-danger">Hapus</a></td>
                        </tr>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                    <tr>
                        <th colspan="4" class="text-end">Total</th>
                        <th colspan="2">Rp <?= number_format($total) ?></th>
                    </tr>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-warning text-center">Keranjang masih kosong.</div>
    <?php endif; ?>

    <div class="mt-4 text-start">
        <a href="produk.php" class="btn btn-kembali">← Kembali Belanja</a>
    </div>
</div>

</body>
</html>